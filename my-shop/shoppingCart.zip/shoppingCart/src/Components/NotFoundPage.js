import React from "react";

const NotFoundPage = (props) => {
  return <div>Page Not Found!</div>;
};
export default NotFoundPage;
