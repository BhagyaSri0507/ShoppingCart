import React from "react";

const Login = (props) => {
  return <div>Login Page</div>;
};
export default Login;
