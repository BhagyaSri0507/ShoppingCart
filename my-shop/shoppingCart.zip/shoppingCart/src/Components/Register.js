import React from "react";

const Register = (props) => {
  return <div>Register Page</div>;
};
export default Register;
